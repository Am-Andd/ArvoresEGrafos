#include <stdio.h>
#include <time.h>

void imprimirArray(int arr[], int n) {
    for(int i = 0; i < n; i++){
        printf("%d ", arr[i]);
    printf("\n");
	}
}

void bubbleSort(int arr[], int n) {
    int i, j, temp;

    printf("\nProcesso do Bubble Sort:\n");

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            printf("Comparando %d e %d\n", arr[j], arr[j+1]);

            if(arr[j] > arr[j+1]) {
                printf("Trocando %d e %d\n", arr[j], arr[j+1]);
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main() {
    int opcao;
    int arr[] = {64, 34, 25, 12, 22, 11, 90};
    int n = sizeof(arr)/sizeof(arr[0]);

    printf("1 - Executar Bubble Sort\n");
    printf("Escolha: ");
    scanf("%d", &opcao);

    if(opcao == 1) {
        clock_t inicio = clock();

        printf("Array original: ");
        imprimirArray(arr, n);

        bubbleSort(arr, n);

        printf("\nArray ordenado: ");
        imprimirArray(arr, n);

        clock_t fim = clock();
        double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;

        printf("Tempo de execucao: %f segundos\n", tempo);
    }

    return 0;
}
