#include <stdio.h>
#include <time.h>

void imprimirArray(int arr[], int n) {
    for(int i = 0; i < n; i++){
        printf("%d ", arr[i]);
    printf("\n");
	}
}

void insertionSort(int arr[], int n) {
    int i, j, chave;

    printf("\nProcesso do Insertion Sort:\n");

    for(i = 1; i < n; i++) {
        chave = arr[i];
        j = i - 1;

        while(j >= 0 && arr[j] > chave) {
            printf("Movendo %d para frente\n", arr[j]);
            arr[j+1] = arr[j];
            j--;
        }

        arr[j+1] = chave;
    }
}

int main() {
    int arr[] = {64, 34, 25, 12, 22, 11, 90};
    int n = sizeof(arr)/sizeof(arr[0]);

    clock_t inicio = clock();

    printf("Array original: ");
    imprimirArray(arr, n);

    insertionSort(arr, n);

    printf("\nArray ordenado: ");
    imprimirArray(arr, n);

    clock_t fim = clock();
    double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;

    printf("Tempo de execucao: %f segundos\n", tempo);

    return 0;
}
