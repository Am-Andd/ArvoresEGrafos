#include <stdio.h>
#include <time.h>

void imprimirArray(int arr[], int n) {
    for(int i = 0; i < n; i++){
        printf("%d ", arr[i]);
    printf("\n");
	}	
}

void selectionSort(int arr[], int n) {
    int i, j, min, temp;

    printf("\nProcesso do Selection Sort:\n");

    for(i = 0; i < n - 1; i++) {
        min = i;

        for(j = i + 1; j < n; j++) {
            printf("Comparando %d e %d\n", arr[min], arr[j]);

            if(arr[j] < arr[min])
                min = j;
        }

        if(min != i) {
            printf("Trocando %d e %d\n", arr[i], arr[min]);
            temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
}

int main() {
    int arr[] = {64, 34, 25, 12, 22, 11, 90};
    int n = sizeof(arr)/sizeof(arr[0]);

    clock_t inicio = clock();

    printf("Array original: ");
    imprimirArray(arr, n);

    selectionSort(arr, n);

    printf("\nArray ordenado: ");
    imprimirArray(arr, n);

    clock_t fim = clock();
    double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;

    printf("Tempo de execucao: %f segundos\n", tempo);

    return 0;
}
